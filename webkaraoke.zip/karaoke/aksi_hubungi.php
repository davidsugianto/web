<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Karaoke</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Custom CSS -->
   <link href="css/small-business.css" rel="stylesheet">

         
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <!-- <img src="http://placehold.it/150x50&text=Logo" alt=""> -->
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                 <?php include "menu.php " ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <!-- Heading Row -->
        <div class="row well">
            <div class="col-md-6">
                <h2>Alamat :</h2>
                <h3> &nbsp;&nbsp; Jl.Example No.109 Jember Jawa Timur,68174</h3><br>
				<h2>No.Telp : </h2>
                <h3>&nbsp;&nbsp;082257844803 </h3><br>
                <h2>E-mail :</h2>
                <h3>&nbsp;&nbsp;Asksong@gmail.com</h3>
               
            <div class="col-md-12">
                <h2>Peta Lokasi</h2><br>
                <!-- <div id="tempat_peta" style="width:500px;height:300px;" class="img-responsive"></div> -->
            <img class="img-responsive" src="img/1.jpg">
          </div></div>
           
            <div class="col-md-6">
                  
<?php
echo "<center><div align='center'><img src='img/icon/2.png'> <br><h1>Terimakasih Telah Menghubungi Kami. Tunggu Balasan Kami Via Email.</h1></div></center>";   

?></div>

             
                 
             
            <!-- /.col-md-4 -->
        </div>
        <!-- /.row -->
</div>
        
<div class="main-spacer">
</div>

        <!-- Footer -->
        <footer>
            
                    <center>Copyright &copy; Bootsrap Team</center>
                
        </footer>


    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    

</body>

</html>
