<script src="<?php echo $base_url; ?>includes/ckeditor/ckeditor.js"></script>
<script src="<?php echo $base_url; ?>includes/ckfinder/ckfinder.js"></script>

<?php
ob_start();
error_reporting(0);
?>
<form name="form1" method="post" action="">
  	  <label>Nama Tipe</label>
      <input type="text" name="nama" id="nama">
      <label>Max Orang</label>
      <input type="text" name="max" id="max">
      <label>Harga Hari biasa</label>
      <input type="text" name="harga" id="harga">
      <label>Harga Sabtu & Minggu</label>
      <input type="text" name="harga1" id="harga1">
      <label>Gambar (akan ditampilkan sebagai thumbnails)</label>
      <input type="text" name="photo" id="photo" onClick="window.open('<?php echo $base_url; ?>includes/imguploads/index.php','popuppage','width=600,toolbar=0,resizable=0,scrollbars=no,height=400,top=100,left=100');">
      <input type="hidden" name="ext" id="ext" />
<input type="hidden" name="nfile" id="nfile" />
<br>
<p></p>
      <label>Deskripsi</label>
      <textarea id="editor1" name="editor1" rows="10" cols="80"></textarea>
   	
      <p></p>
      <input type="submit" class="btn btn-primary" name="button" id="button" value="Tambah">
</form>
<script type="text/javascript">

// This is a check for the CKEditor class. If not defined, the paths must be checked.
if ( typeof CKEDITOR == 'undefined' )
{
	document.write(
		'<strong><span style="color: #ff0000">Error</span>: CKEditor not found</strong>.' +
		'This sample assumes that CKEditor (not included with CKFinder) is installed in' +
		'the "/ckeditor/" path. If you have it installed in a different place, just edit' +
		'this file, changing the wrong paths in the &lt;head&gt; (line 5) and the "BasePath"' +
		'value (line 32).' ) ;
}
else
{
	var editor = CKEDITOR.replace( 'editor1' );	

	// Just call CKFinder.SetupCKEditor and pass the CKEditor instance as the first argument.
	// The second parameter (optional), is the path for the CKFinder installation (default = "/ckfinder/").
	CKFinder.setupCKEditor( editor, '<?php echo $base_url; ?>includes/ckfinder/' ) ;

	// It is also possible to pass an object with selected CKFinder properties as a second argument.
	// CKFinder.SetupCKEditor( editor, { BasePath : '../../', RememberLastFolder : false } ) ;
}

		</script>
<?php
if(isset($_POST["button"]))
{
	$nid=_getautoinc("tb_tipe");
	$rs=mysql_query("INSERT INTO `karaoke1`.`tb_tipe` (`tipe`, `harga_biasa`,`harga_sabming`, `deskripsi`,`max`, `gambar`) VALUES ('".$_POST['nama']."','".$_POST['harga']."','".$_POST['harga1']."', '".strip_tags($_POST['editor1'])."','".$_POST['max']."','".$_POST['photo']."')");
	
}
ob_end_flush();
?>