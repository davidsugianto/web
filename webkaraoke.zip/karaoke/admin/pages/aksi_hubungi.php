<?php


  include "../../config.php";
  
  $module = $_GET['p'];
  $act    = $_GET['act'];
    
  // Hapus hubungi
  if ($module=='hubungi' AND $act=='hapus'){
    $hapus = "DELETE FROM tb_hubungi WHERE id_hubungi='$_GET[id]'";
    mysql_query($hapus);
    
    header("location: ../index.php?p=".$module);
 
}
?>
