 <script>
$(function() {
$("#datepicker").datepicker({        
		 dateFormat: "yyyy-mm-dd",
    });
});
 $(function() {
$("#datepicker2").datepicker({        
		 dateFormat: "yyyy-mm-dd",
    });
});

</script>
<style>
.ui-datepicker td {
    border: 1px solid #CCC;
    padding: 0;
}

.ui-state-default,
.ui-widget-content .ui-state-default,
.ui-widget-header .ui-state-default {
    border: solid #FFF;
    border-width: 1px 0 0 1px;
}

</style>
<?php
$sql1 = "SELECT * FROM tb_pemesan";
		$q1= mysql_query($sql1);
		$r=mysql_fetch_array($q1); 
?>
<form action="" method="post">
Dari <input name="tgl1" type="date" id="datepicker" value=""> Hingga <input name="tgl2" type="date" id="datepicker2" value="">
<input type="submit" name="button" class="btn btn-primary btn-large" value="Cari">
</form>
<hr>

<span class="span4">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="table">
  <tr>
		<th bgcolor="#CCCCCC">Id</th>
		<th  bgcolor="#CCCCCC">Untuk_Tanggal</th>
		<th bgcolor="#CCCCCC">Dari_Jam</th>
		<th  bgcolor="#CCCCCC">Sampai_Jam</th>
		<th  bgcolor="#CCCCCC">Nama_Pemesan</th>
		<th  bgcolor="#CCCCCC">No.Telp</th>
		<th  bgcolor="#CCCCCC">Tipe_Ruangan</th>
		<th  bgcolor="#CCCCCC">Nomor_Ruangan</th>
   
  </tr>
  <?php
if(isset($_POST['button']))
{
	
	$originalDate1 = $_POST['tgl1'];
	$newDate1 = date("Y-m-d", strtotime($originalDate1));
	$originalDate2 = $_POST['tgl2'];
	$newDate2 = date("Y-m-d", strtotime($originalDate2));
	


$sql = "SELECT tb_pemesan.id_pemesan, tb_pemesan.tgl_pesan, tb_pemesan.waktu_masuk, tb_pemesan.waktu_keluar as a, tb_pemesan.nama,
 tb_pemesan.telp, tb_pemesan.alamat, tb_pemesan.nomor_ruang,tb_tipe.tipe 
FROM tb_pemesan LEFT JOIN tb_tipe ON tb_pemesan.id_tipe = tb_tipe.id_tipe Where tb_pemesan.tgl_pesan between '".$newDate1."' and '".$newDate2."' ";
		$q = mysql_query($sql) or die(mysql_error());
		$h=mysql_num_rows($q);
			if($h!=0 ){

			while($hasil=mysql_fetch_array($q))
	{

?>
  <tr>
  	<td><?= $hasil['id_pemesan'] ?></td>
		<td ><?= $hasil['tgl_pesan'] ?></td>
		<td><?= $hasil['waktu_masuk'] ?></td>
		<td><?= $hasil['a'] ?></td>
		<td><?= $hasil['nama'] ?></td>
		<td><?= $hasil['telp'] ?></td>
		<td><?=$hasil['tipe'] ?></td>
		<td><?= $hasil['nomor_ruang']?></td>

  </tr>
<?php
	}
}else {
	
        echo "<script type='text/javascript'>alert(' Data Kosong') ;</script>";
		_direct('index.php?p=repbulan');


}

}
?>
</table>
