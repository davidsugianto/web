<?php
$sessi=$_SESSION['sessi'];
if(isset($_POST['pencet'])){
    $lama=mysql_real_escape_string($_POST['lama']);
    $lama=md5($lama);
    $baru=mysql_real_escape_string($_POST['baru']);
    $ulangi=mysql_real_escape_string($_POST['ulangi']);
    $new=md5($ulangi);
    $k=mysql_fetch_array(mysql_query("select password from tb_login where username='$sessi'"));
    if($lama == $k['password']){
        if($baru != '' && $ulangi != ''){       
            if($baru == $ulangi){
             $input=mysql_query("update tb_login set password='$new' where username='$sessi'");
             if($input){
                echo "<script type='text/javascript'> alert('Kunci Berhasil di Ganti !');</script>";
				_direct('logout.php');
             }else{
               echo "<script type='text/javascript'> alert('Kunci Gagal di Ganti !');</script>"; 
             }
            }else{
             echo "<script type='text/javascript'> alert('Konfirmasi Sandi Baru Tidak Cocok !');</script>";
            }
        }else{
            echo "<script type='text/javascript'> alert('Sandi Baru Tidak Boleh Kosong !');</script>";
        }
    }else{
        echo "<script type='text/javascript'> alert('Sandi Lama Tidak Cocok');</script>";
    }
}
?>
<html>
<head>
    <title>Ganti Kunci Admin</title>
</head>
<body bgcolor='silver'>
<form action='' method='post'>
<table style='font-size: 12px; '>
    <tr>
        <td colspan='3'><img src='../img/icon/kunci.png'> Ganti Kunci Admin<hr></td>
    </tr>
    <tr>
        <td>Kunci Sekarang</td><td>:</td><td><input type='password' name='lama'></td>
    </tr>
    <tr>
        <td>Kunci Baru</td><td>:</td><td><input type='password' name='baru'></td>
    </tr>
    <tr>
        <td>Ulangi Kunci Baru</td><td>:</td><td><input type='password' name='ulangi'></td>
    </tr>
    <tr>
        <td colspan='3'><hr><input type='submit' value='Ganti' name='pencet'></td>
    </tr>
</table>
</form>
</body>
</html>