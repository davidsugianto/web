<?php
include "../../config.php";
	$namaFile = "Datapemesan.xls";
	header("Content-type: application/octet-stream");
	header("Content-Disposition: attachment; filename=".$namaFile."");
	header("Pragma: no-cahce");
	header("Expires: 0");
	
	//session_start();
	

$sql = "SELECT tb_pemesan.id_pemesan, tb_pemesan.tgl_pesan,tb_pemesan.waktu_masuk,tb_pemesan.waktu_keluar,tb_pemesan.nama,tb_pemesan.telp,
tb_tipe.tipe,tb_pemesan.nomor_ruang FROM tb_pemesan, tb_tipe where tb_pemesan.id_pemesan=tb_pemesan.id_pemesan and tb_tipe.id_tipe=tb_pemesan.id_tipe";
$query = mysql_query($sql);
	
?>


<h2>Data Pelanggan ASK SONG KARAOKE</h2>
<table border="1">
	<tr>
	<th align = "center " width = "30" bgcolor="#CCCCCC">No</th>
		<th align = "center " width = "80" bgcolor="#CCCCCC">Id_pemesan</th>
		<th align = "center " width = "60" bgcolor="#CCCCCC">Untuk Tanggal</th>
		<th align = "center " width = "60" bgcolor="#CCCCCC">Dari Jam</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">Sampai Jam</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">Nama Pemesan</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">No Telp</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">Tipe Ruangan</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">Nomor Ruangan</th>
	</tr>
<?php
	$no = 1;
	while($hasil = mysql_fetch_array($query)) {
?>
	<tr>
    		<td> <?= $no ?></td>
			<td><?= $hasil['id_pemesan'] ?></td>
		<td ><?= $hasil['tgl_pesan'] ?></td>
		<td><?= $hasil['waktu_masuk'] ?></td>
		<td><?= $hasil['waktu_keluar'] ?></td>
		<td><?= $hasil['nama'] ?></td>
		<td><?= $hasil['telp'] ?></td>
		<td><?= $hasil['tipe'] ?></td>
		<td><?= $hasil['nomor_ruang'] ?></td>
        </tr>
<?php
		$no++;
	}
?>
</table>