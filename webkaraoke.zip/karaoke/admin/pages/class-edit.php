<script src="<?php echo $base_url; ?>includes/ckeditor/ckeditor.js"></script>
<script src="<?php echo $base_url; ?>includes/ckfinder/ckfinder.js"></script>
<?php
ob_start();
 error_reporting(0);
 
if(isset($_GET['id']))
{

	
$q=mysql_query("Select * from tb_tipe where sha1(id_tipe)='".$_GET['id']."'");
$r=mysql_fetch_array($q);


}
?>
<form name="form1" method="post" action="">
  	  <label>Nama Tipe</label>
      <input type="text" name="nama" id="nama" value="<?php echo $r['tipe']; ?>">
       <label>Max Orang</label>
      <input type="text" name="max" id="max" value="<?php echo $r['max']; ?>">
      <label>Harga Hari Biasa</label>
      <input type="text" name="harga" id="harga" value="<?php echo $r['harga_biasa']; ?>">
      <label>Harga Sabtu & Minggu</label>
      <input type="text" name="harga1" id="harga" value="<?php echo $r['harga_sabming']; ?>">

      <label>Gambar (akan ditampilkan sebagai thumbnails)</label>
      <input type="text" name="photo" id="photo" onClick="window.open('<?php echo $base_url; ?>includes/imguploads/index.php','popuppage','width=600,toolbar=0,resizable=0,scrollbars=no,height=400,top=100,left=100');" value="<?php echo $r['gambar']; ?>">
      <input type="hidden" name="ext" id="ext" />
<input type="hidden" name="nfile" id="nfile" />

      <label>Deskripsi</label>
      <textarea id="editor1" name="editor1" rows="10" cols="80"> <?php echo $r['deskripsi']; ?></textarea>
   
      <p></p>
      <input type="submit" class="btn btn-primary" name="button" id="button" value="Update">
</form>
<script type="text/javascript">

// This is a check for the CKEditor class. If not defined, the paths must be checked.
if ( typeof CKEDITOR == 'undefined' )
{
	document.write(
		'<strong><span style="color: #ff0000">Error</span>: CKEditor not found</strong>.' +
		'This sample assumes that CKEditor (not included with CKFinder) is installed in' +
		'the "/ckeditor/" path. If you have it installed in a different place, just edit' +
		'this file, changing the wrong paths in the &lt;head&gt; (line 5) and the "BasePath"' +
		'value (line 32).' ) ;
}
else
{
	var editor = CKEDITOR.replace( 'editor1' );	
	
	// Just call CKFinder.SetupCKEditor and pass the CKEditor instance as the first argument.
	// The second parameter (optional), is the path for the CKFinder installation (default = "/ckfinder/").
	CKFinder.setupCKEditor( editor, '<?php echo $base_url; ?>includes/ckfinder/' ) ;

	// It is also possible to pass an object with selected CKFinder properties as a second argument.
	// CKFinder.SetupCKEditor( editor, { BasePath : '../../', RememberLastFolder : false } ) ;
}

		</script>
<?php
$tipe=$_POST['nama'];
$harga1=$_POST['harga'];
$harga2=$_POST['harga1'];
$max=$_POST['max'];
$desk=$_POST['editor1'];
$gambar=$_POST['photo'];
if(isset($_POST["button"]))
{	
	$nid=$_GET['act'];
	$rs=mysql_query("Update tb_tipe SET `tipe`='$tipe',`max`='$max',`harga_biasa`='$harga1',`harga_sabming`='$harga2',`deskripsi`= '$desk',`gambar`='$gambar' Where sha1(id_tipe)='".$_GET['id']."'");
	_direct("?p=class");
}

ob_end_flush();
?>
