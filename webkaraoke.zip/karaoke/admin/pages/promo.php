<script src="<?php echo $base_url;?>includes/ckeditor/ckeditor.js"></script>
<script src="<?php echo $base_url;?>includes/ckfinder/ckfinder.js"></script>

   <script>
$(function() {
$( "#datepicker" ).datepicker();
});
$(function() {
$( "#datepicker2" ).datepicker();
});
</script>
<style>
.ui-datepicker td {
    border: 1px solid #CCC;
    padding: 0;
}

.ui-state-default,
.ui-widget-content .ui-state-default,
.ui-widget-header .ui-state-default {
    border: solid #FFF;
    border-width: 1px 0 0 1px;
}

</style>
<?php
error_reporting(0);
$q=mysql_query("Select * from tb_promo");
$r=mysql_fetch_array($q);
?>
<form action="" method="post">
<label>Tipe Ruangan</label>
				<select name="jenis" class="required" id="selectBox">

					<option value="">- please select -</option>
                    <?php
					$q2=mysql_query("Select * from tb_tipe");
					while($r2=mysql_fetch_array($q2))
					{
					?>
					<option value="<?php echo $r2['id_tipe']; ?>"><?php echo $r2['tipe']; ?></option>
                    <?php
					}
					?>
				</select>
<label>Judul Promo</label>
<input type="text" name="judul" class="input-large" value="<?php echo $r['judul_promo']; ?>"/>
<label>Diskon (dalam persen)</label>
<input type="text" name="diskon" class="input-small" value="<?php echo $r['diskon']; ?>"/>%<br />
Dari <input name="tgl1" type="date" id="datepicker" value="<?php echo $r['tgl_mulai']; ?>"> Sampai 
<input name="tgl2" type="date" id="datepicker2" value="<?php echo $r['tgl_akhir']; ?>">
<label>Deskripsi</label>
<textarea id="editor1" name="editor1" rows="10" cols="80"> <?php echo $r['deskripsi']; ?></textarea>
<input type="submit" class="btn btn-primary" name="button" id="button" value="Update">
</form>
<script type="text/javascript">

// This is a check for the CKEditor class. If not defined, the paths must be checked.
if ( typeof CKEDITOR == 'undefined' )
{
	document.write(
		'<strong><span style="color: #ff0000">Error</span>: CKEditor not found</strong>.' +
		'This sample assumes that CKEditor (not included with CKFinder) is installed in' +
		'the "/ckeditor/" path. If you have it installed in a different place, just edit' +
		'this file, changing the wrong paths in the &lt;head&gt; (line 5) and the "BasePath"' +
		'value (line 32).' ) ;
}
else
{
	var editor = CKEDITOR.replace( 'editor1' );	
	
	// Just call CKFinder.SetupCKEditor and pass the CKEditor instance as the first argument.
	// The second parameter (optional), is the path for the CKFinder installation (default = "/ckfinder/").
	CKFinder.setupCKEditor( editor, '<?php echo $base_url; ?>includes/ckfinder/' ) ;

	// It is also possible to pass an object with selected CKFinder properties as a second argument.
	// CKFinder.SetupCKEditor( editor, { BasePath : '../../', RememberLastFolder : false } ) ;
}

		</script>
        
<?php
if(isset($_POST['button']))
{
	$q=mysql_query("Update tb_promo SET id_tipe='".$_POST['jenis']."',deskripsi='".$_POST['editor1']."',judul_promo='".$_POST['judul']."',
	tgl_mulai='".$_POST['tgl1']."',tgl_akhir='".$_POST['tgl2']."',diskon='".$_POST['diskon']."'");
	if($q)
	{
		_direct("?p=promo");
	}
}
 ?>