<?php
ob_start();
error_reporting(0);
?>
<form name="form1" method="post" action="">
  	  <label>Judul Lagu	</label>
      <input type="text" name="judul">
      <label>Penyanyi / Artis</label>		
 <select name="penyanyi" class="required" id="selectBox">
	<option value="">- Silahkan Pilih -</option>
                    <?php
					$q2=mysql_query("Select * from tb_artis");
					while($r2=mysql_fetch_array($q2))
					{
					?>
					<option value="<?php echo $r2['id_artis']; ?>"><?php echo $r2['nama']; ?></option>
                    <?php
					}
					?> 
				</select>&nbsp;&nbsp; &nbsp;<a href="?p=artis">Tambah Artis ?</a>
      
      
      <label>Jenis lagu</label>
      <select name="jenis" class="required" id="selectBox">
      <option value="">- Silahkan Pilih - </option>
      <option value="POP">POP</option>
      <option value="ROCK">ROCK</option>
      <option value="JAZZ">JAZZ</option>
      <option value="DANGDUT">DANGDUT</option>
      <option value="KERONCONG">KERONCONG</option>
      <option value="CLASSIC">CLASSIC</option>
      </select>
      <label>Tahun Rilis</label>
      <select name='thn'>
                            <option value=''>- Silahkan Pilih -</option>
                            <?php for ($tgl=1945; $tgl <= date('Y'); $tgl++){
                             echo  "<option value='".$tgl."'>".$tgl."</option> " ;
                            };
                            ?>
                        </select>
      <label>Asal / Bahasa </label>
      <select name="bhs" class="required" id="selectBox">
      <option value="">- Silahkan Pilih - </option>
      <option value="indo">Indonesia</option>
      <option value="jawa">Jawa</option>
      <option value="indo">Indonesia</option>
      <option value="inggris">Inggris</option>
      <option value="India">India</option>
      <option value="Jepang">Jepang</option>
      
      </select>
      <!--
      <label>Gambar (akan ditampilkan sebagai thumbnails)</label>
      <input type="text" name="photo" id="photo" onClick="window.open('<?php //echo $base_url; ?>includes/imguploads/index.php','popuppage','width=600,toolbar=0,resizable=0,scrollbars=no,height=400,top=100,left=100');">
      <input type="hidden" name="ext" id="ext" />
<input type="hidden" name="nfile" id="nfile" />-->
<br>
<p></p>
      
   	
      <p></p>
      <input type="submit" class="btn btn-primary" name="button" id="button" value="Tambah">
</form>

<?php
if(isset($_POST["button"]))
{
		$nid=_getautoinc("tb_daftarlagu");
	$rs=mysql_query("INSERT INTO tb_daftarlagu VALUES (' ','".$_POST['penyanyi']."','".$_POST['judul']."','".$_POST['jenis']."','".$_POST['thn']."','".$_POST['bhs']."')");
	_direct('index.php?p=lagu');
}
ob_end_flush();
?>