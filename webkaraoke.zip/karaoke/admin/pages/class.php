
<div>
<table width="50%" border="0" cellspacing="0" cellpadding="0" class="table table-condensed">
  <tr>
    <td ><center>Nama Tipe</center></td>
    <td><center>Harga Hari Biasa</center></td>    
    <td><center>Harga Hari Sabtu & Minggu </center></td>
    <td><center>Gambar </center></td>
    <td >Max orang</td>
    <td>Aksi</td>
  </tr>
  <?php
  error_reporting(0);
  $rw=mysql_query("Select * from tb_tipe");
  while($s=mysql_fetch_array($rw))
  {
	  $photo=$base_url."uploads/images/".$s['gambar'];
  ?>
  <tr>
    <td><center><?php echo $s['tipe']; ?></center></td>
    <td><center> Rp.<?php echo number_format($s['harga_biasa']); ?></center></td>
    <td><center> Rp.<?php echo number_format($s['harga_sabming']); ?></center></td>

    <td><div class="picture">
    
    <center><a href="<?php echo $photo; ?>" data-rel="prettyPhoto" title=""><span class="magnify"></span><img src="<?php echo $photo; ?>" alt="<?php echo $s['tipe']; ?>" class="scale-with-grid" width="90" height="90"></a></center><em></em>
    
    </div></td> 
    <td> <center><?php echo $s['max'] ?></center></td>
    
    
    <td><a href="?p=class-edit&id=<?php echo sha1($s['id_tipe']); ?>&act=<?php echo $s['id_tipe']; ?>">Edit</a> - <a href="?p=class&del=1&id=<?php echo sha1($s['id_tipe']); ?>">Hapus</a></td>
  </tr>
  <?php
  }
  ?>
</table>
</span>
<?php
if(isset($_GET['del']))
{
	$ids=$_GET['id'];
	$ff=mysql_query("Delete from tb_tipe Where sha1(id_tipe)='".$ids."'");
	if($ff)
	{
		echo "<script>window.location='?p=class'</script>";
	}
}

function _toimg($str)
{
	$im="";
	if($str=="0")
	{
		$im='<i class="icon-remove">';
	}elseif($str=="1")
	{
		$im= '<i class="icon-ok">';
	}
	return $im;
}
?>


