<?php
ob_start();
error_reporting(0);

?>
<form name="form1" method="post" action="">
  	  <label>Nama Penyanyi/Band	</label>
      <input type="text" name="nama">
      <label>Gambar (akan ditampilkan sebagai thumbnails)</label>
      <input type="text" name="photo" id="photo" onClick="window.open('<?php echo $base_url; ?>includes/imguploads/indexpunyaartis.php','popuppage','width=600,toolbar=0,resizable=0,scrollbars=no,height=400,top=100,left=100');">
      <input type="hidden" name="ext" id="ext" />
<input type="hidden" name="nfile" id="nfile" />
<br>
<p></p>
      
   	
      <p></p>
      <input type="submit" class="btn btn-primary" name="button" id="button" value="Tambah">
</form>

<?php
if(isset($_POST["button"]))
{
	if($_POST['nama']!='' ){
	$nama = addslashes (strip_tags ($_POST['nama']));
	$foto=$_POST['photo'];
	//insert ke tabel
	$rs="INSERT INTO tb_artis VALUES (' ','$nama','$foto')";
	$sql = mysql_query ($rs) or die (mysql_error());
	if ($sql) {
		echo "<h2><font color=blue>Berhasil</font></h2>";
		_direct('index.php?p=lagu');	
	} else {
		echo "<h2><font color=red>Gagal</font></h2>";	
	}
	//$nid=_getautoinc("tb_daftarlagu");
	}else {
	echo "<script type='text/javascript'>alert('nama tidak boleh kosong') ;</script>";}
}
ob_end_flush();
?>