<?php
//CORE
require_once('config.php');
require_once('includes/functions/publicfunc.php');
require_once('includes/functions/dbfunc.php');
?>

<?php
$q=mysql_query("Select * from tb_tipe LIMIT 0,3");
while($r=mysql_fetch_array($q))
{
	$photo=$base_url."uploads/images/".$r['gambar'];
	$id=$r['id_tipe'];
	

?>
<div class="four columns add-bottom">
	<div class="picture">
		<a href="<?php echo $photo; ?>" data-rel="prettyPhoto" title=""><span class="magnify"></span><img src="<?php echo $photo; ?>" alt="picture" class="scale-with-grid"></a><em></em>
	</div>
	<h3><?php echo $r['tipe']; ?> <strong><?php echo ("Rp.").$r['harga1']; ?></strong></h3>
	
	<ul class="room_facilities">
    
	</ul>
	<br class="clear add-bottom"/>
	<a href="<?php echo $base_url."?room="._encodeParam($id); ?>" class="button">Read more</a>
</div>
<?php
}
?>