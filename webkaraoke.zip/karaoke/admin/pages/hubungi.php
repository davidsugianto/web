<script src="<?php echo $base_url; ?>includes/ckeditor/ckeditor.js"></script>
<script src="<?php echo $base_url; ?>includes/ckfinder/ckfinder.js"></script>
<script type="text/javascript">

<script>
$(function() {
$( "#datepicker" ).datepicker();
});
$(function() {
$( "#datepicker2" ).datepicker();
});
</script>
<style>
.ui-datepicker td {
    border: 1px solid #CCC;
    padding: 0;
}

.ui-state-default,
.ui-widget-content .ui-state-default,
.ui-widget-header .ui-state-default {
    border: solid #FFF;
    border-width: 1px 0 0 1px;
}

</style>
<?php

ob_start();
error_reporting(0);

// mengatasi variabel yang belum di definisikan (notice undefined index)
  $act = isset($_GET['act']) ? $_GET['act'] : ''; 
$aksi = "pages/aksi_hubungi.php";
  switch($act){
    // Tampil Hubungi Kami
    default:
 $sql=@mysql_query("select * from tb_hubungi order by id_hubungi DESC");
                    $jdt=mysql_num_rows($sql);
                    ?>
                   <h2>Hubungi Kami</h2>
          <p>Untuk menjawab/membalas email, klik pada alamat email yang ada di kolom Email.</p>
          <table class="table">
          <thead>
          <tr><th>No</th><th>Nama Pengirim</th><th>Email</th><th>Subjek</th><th>Tanggal</th><th>Aksi</th></tr>
          </thead><tbody>
                    
                    <?php
					$no = 1;
      while ($r=mysql_fetch_array($sql)){  
        $tanggal=tgl_indo($r['tanggal']);
        echo "<tr><td>$no</td>
                  <td>$r[nama_pengirim]</td>
                  <td><a href=\"?p=hubungi&act=balasemail&id=$r[id_hubungi]\">$r[email]</a></td>
                  <td>$r[subjek]</td>
                  <td>$tanggal</a></td>
                  <td><a href=\"$aksi?p=hubungi&act=hapus&id=$r[id_hubungi]\">Hapus</a></td>
              </tr>";
        $no++;
      }
      echo "</tbody>
        </table><br>";
	break;	

  case "balasemail":
      $query = "SELECT * FROM tb_hubungi WHERE id_hubungi='$_GET[id]'";
      $hasil = mysql_query($query);
      $r     = mysql_fetch_array($hasil);
      
      echo "<h2>Balas Email</h2>
          <form method=\"POST\" action=\"?p=hubungi&act=kirimemail\">
          <table>
          <tr><td>Kepada</td><td> : <input type=\"text\" name=\"email\" value=\"$r[email]\"></td></tr>
          <tr><td>Subjek</td><td> : <input type=\"text\" name=\"subjek\" value=\"Re: $r[subjek]\"></td></tr>
          <tr><td>Pesan</td> <td>   <textarea name=\"pesan\" id=\"editor1\" style=\"width: 800px; height: 180px;\"><br><br>    
          -----------------------------------------------------------------------------------------------------------------------------------------------<br>
          $r[pesan]</textarea></td></tr>
          <tr><td colspan=\"2\"><input type=\"submit\" value=\"Kirim\">
                                <input type=\"button\" value=\"Batal\" onclick=\"self.history.back()\"></td></tr>
          </table>
          </form>";
    break;
	 case "kirimemail":
      $query = "SELECT pemilik,email FROM tb_email LIMIT 1";
      $hasil = mysql_query($query);
      $r     = mysql_fetch_array($hasil);
      
      $kepada = $_POST['email']; 
      $subjek = $_POST['subjek'];
      $pesan  = $_POST['editor1'];
       
      $dari  = "from: $r[nama_pemilik] <$r[email]> \r\n";
      $dari .= "Content-type: text/html \r\n"; // isi email support html

      mail($email,$subjek,$pesan,$dari);
      
      echo "<h2>Status Email</h2>
            <p>Email telah terkirim.</p>";	 		  
    break;  
  
  }
  ?>
                    
                    
                    
                    
                    
                    
                    
                    
                    <script type="text/javascript">

// This is a check for the CKEditor class. If not defined, the paths must be checked.
if ( typeof CKEDITOR == 'undefined' )
{
	document.write(
		'<strong><span style="color: #ff0000">Error</span>: CKEditor not found</strong>.' +
		'This sample assumes that CKEditor (not included with CKFinder) is installed in' +
		'the "/ckeditor/" path. If you have it installed in a different place, just edit' +
		'this file, changing the wrong paths in the &lt;head&gt; (line 5) and the "BasePath"' +
		'value (line 32).' ) ;
}
else
{
	var editor = CKEDITOR.replace( 'editor1' );	
	
	// Just call CKFinder.SetupCKEditor and pass the CKEditor instance as the first argument.
	// The second parameter (optional), is the path for the CKFinder installation (default = "/ckfinder/").
	CKFinder.setupCKEditor( editor, '<?php echo $base_url; ?>includes/ckfinder/' ) ;

	// It is also possible to pass an object with selected CKFinder properties as a second argument.
	// CKFinder.SetupCKEditor( editor, { BasePath : '../../', RememberLastFolder : false } ) ;
}

		</script>
        
                    <?php
					

ob_end_flush();

?>
