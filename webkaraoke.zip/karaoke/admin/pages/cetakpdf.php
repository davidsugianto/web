<?php
include "tcpdf/tcpdf.php";
include "../../config.php";
include "../../includes/functions/publicfunc.php";

$sql = "SELECT tb_pemesan.id_pemesan, tb_pemesan.tgl_pesan,tb_pemesan.waktu_masuk,tb_pemesan.waktu_keluar,tb_pemesan.nama,tb_pemesan.telp,tb_tipe.tipe,
tb_pemesan.nomor_ruang FROM tb_pemesan, tb_tipe where tb_pemesan.id_pemesan=tb_pemesan.id_pemesan and tb_tipe.id_tipe=tb_pemesan.id_tipe";
		$q = mysql_query($sql);
		
		
$file = new TCPDF('L','mm','Legal');

$file->SetCreator(PDF_CREATOR);
$file->SetAuthor('Kelompok 4');
$file->SetTitle('Laporan Data Pemesanan Ruangan Pada SI Web Karaoke');
$file->SetSubject('Pemesanan');
$file->SetKeywords('laporan, Pemesanan, Karaoke');

$file->AddPage();
//$file->SetMargins('100px','600px','100');
$file->SetFont("times", "", 12);
$file->SetFont("times", "B", 32);
$file->Cell(0,0,"ASK SONG KARAOKE",0,1,"C");
//$file->SetFont("times", "B", 32);
//$file->Cell(0,0,"DIPLOMA IPB",0,1,"C");
$file->SetFont("times", "", 12);

$html = '<h1>Data Pemesan</h1><u>Lampiran :</u> 1 Berkas<br><hr>&nbsp;<br><br>';
$html .= '<table border="2" cellpadding="0">
	<tr>
		<th align = "center " width = "30" bgcolor="#CCCCCC">No</th>
		<th align = "center " width = "60" bgcolor="#CCCCCC">Id_pemesan</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">Untuk Tanggal</th>
		<th align = "center " width = "80" bgcolor="#CCCCCC">Dari Jam</th>
		<th align = "center " width = "80" bgcolor="#CCCCCC">Sampai Jam</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">Nama Pemesan</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">No Telp</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">Tipe Ruangan</th>
		<th align = "center " width = "100" bgcolor="#CCCCCC">Nomor Ruangan</th>
	
	</tr>
	';

$no = 1;
	while($hasil = mysql_fetch_array($q)) {
		$html .= '
	<tr>
		<td> '.$no.'</td>
		<td align="center">'.$hasil['id_pemesan'].'</td>
		<td align="center" >'.tgl_indo($hasil['tgl_pesan']).'</td>
		<td align="center">'.$hasil['waktu_masuk'].'</td>
		<td align="center">'.$hasil['waktu_keluar'].'</td>
		<td align="center">'.$hasil['nama'].'</td>
		<td align="center">'.$hasil['telp'].'</td>
		<td align="center">'.$hasil['tipe'].'</td>
		<td align="center">'.$hasil['nomor_ruang'].'</td>

	</tr>';
		$no++;
	}
$html .= '</table><br><br><br>Jember, '.tgl_indo(date('Y-m-d')).'<br>
<b>Admintrator </b><br><br><br><br>
<u>Kelompok 4</u>';

$file->writeHTML($html);

$file->Output("Pemesan.pdf","I");


?>