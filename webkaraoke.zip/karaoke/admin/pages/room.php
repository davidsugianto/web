<script type="text/javascript">

   function changeFunc() {
    var selectBox = document.getElementById("selectBox");
    var selectedValue = selectBox.options[selectBox.selectedIndex].value;
    window.location='?p=room&id=' + selectedValue;	
   }

  </script>
<form action="" method="post">
<label>Tipe Room</label>
				<select name="rooms" class="required" id="selectBox" onChange="changeFunc()">
                	<?php
					//echo $_GET['id_tipe'];
					if(isset($_GET['id']))
					{
						$p=mysql_query("Select * from tb_tipe where id_tipe='".$_GET['id']."'");
						$p2=mysql_fetch_array($p);
						echo '<option value="'.$p2['id_tipe'].'">'.$p2['tipe'].'</option>';
					}
					?>
					<option value="">- please select -</option>
                    <?php
					$q=mysql_query("Select * from tb_tipe");
					while($r=mysql_fetch_array($q))
					{
					?>
					<option value="<?php echo $r['id_tipe']; ?>"><?php echo $r['tipe']; ?></option>
                    <?php
					}
					?>
				</select>

<?php
if(isset($_GET['id']))
{
	$p=mysql_query("Select count(id_ruang) as nr,nama_ruang from tb_ruangan where id_tipe='".$_GET['id']."'");
	$nr=mysql_fetch_array($p);
	$rs=$nr['nr'];	
	echo '<label>Jumlah Ruangan</label>';
	echo '<input type="text" name="jumlah" class="input-xxlarge" value="'.$rs.'">';
	echo '<label>Nama Ruangan</label>';
	echo '<input type="text" name="nspace" class="input-xxlarge" value="'.$nr['nama_ruang'].'">';
	echo '<p></p><p></p>';
	echo '<input type="submit" value="Update" name="button">';
}
?>



</form>

<?php

if(isset($_POST['button']))
{

		mysql_query("Delete from tb_ruangan where id_tipe='".$_GET['id']."'");
		$jml=$_POST['jumlah'];
			for ($i = 1; $i <= $jml; $i++) {
				$sp=$_POST['nspace'].$i;
				mysql_query("Insert into tb_ruangan (`nomor_ruang`,`id_tipe`,`status`,`nama_ruang`) values ('".$sp."','".$_GET['id']."','0','".$_POST['nspace']."')");
			}
			_direct("?p=room");
		
		

}
?>