<?php
session_start();
include("../config.php");
require_once('../includes/functions/publicfunc.php');
require_once('../includes/functions/dbfunc.php');
$pencet=$_POST['go'];
$nama=mysql_real_escape_string($_POST['nama']);
$kunci=md5($_POST['kunci']);

//jika menekan tmbol login & nama tidak kosong
if ($pencet != '' && $nama != '' && $kunci != ''){
    //jalankan query
    
    $s=mysql_query("select * from tb_login where username='".$nama."' and password='".$kunci."'");
    //cek banyak data
    $c=mysql_num_rows($s);
    //jika data cocok
	
    if($c == '1'){
      $t= mysql_fetch_array($s);
      $_SESSION['sessi']=$t['username'];
      //echo $t['nama'];
     // $login=$t['login'] + 1;
     // mysql_query("update admin set login='$login', sedang_login='ya' where username='$nama'");
    }else{
      echo "<script type='text/javascript'> alert('Nama dan Kunci tidak cocok !');</script>";
    }
};
//
if(isset($_SESSION['sessi'])){
   _direct('index.php'); 
}
?>
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset="UTF-8" /> 
    <title>
       ADMINISTRATOR
    </title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<form method="post">
  <h1>Admin Area</h1>
  <div class="inset">
  <p>
    <label for="email">USERNAME</label>
    <input type="text" name="nama"  placeholder="Masukkan Username" >
  </p>
  <p>
    <label for="password">PASSWORD</label>
    <input type="password" name="kunci" placeholder="Masukkan Password">
  </p>
  <p>
 <center><input type="submit" name="go" value="Log in"></center>
</p></div>
</form>

</body>
</html>
