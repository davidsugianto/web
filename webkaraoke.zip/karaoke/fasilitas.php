<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Karaoke</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

   <!-- Custom CSS -->
   <link href="css/small-business.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <!-- <img src="http://placehold.it/150x50&text=Logo" alt=""> -->
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                <?php include "menu.php " ?>

            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

           <!-- Call to Action Well -->
        <div class="row">
            <div class="col-lg-12">
                <div class="well text-center">
                    <h1><center>fasilitas</center></h1>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->


        <!-- Content Row -->
        <div class="well text-center">
            <div class="row">
            <div class="col-lg-12">
              <div class="col-md-4"> 
          
                  <img src="img/fasilitas/hd.PNG" title="Setiap video klip dari lagu-lagu yang tersedia, memiliki kualitas gambar yang bagus." class="img-circle" alt="hd" width="304" height="236">
              </div>
              <div class="col-md-4">
 <img src="img/fasilitas/lagu.png" title="Memiliki koleksi lagu yang lengkap dan up to date. Di antaranya adalah lagu Indonesia, lagu Barat, lagu India, lagu Korea, lagu Jepang dan masih banyak lagi." class="img-circle" alt="lagu" width="304" height="236">
              </div>
              <div class="col-md-4">
                  <img src="img/fasilitas/lampu.jpg" title="Semua ruang karaoke akan dipercantik oleh lampu LED yang berbagai macam warna dan motif nya." class="img-circle" alt="lampu" width="304" height="236">
              </div>
              <div class="col-lg-1">
              <br>
<br></div>

            <!-- Content Row -->
            <div class="row">
            <div class="col-lg-12">
              <div class="col-md-4">
<img src="img/fasilitas/makanan.jpg" title="Food & Beverage berbahan baku pilihan yang berkualitas serta fresh tetapi mengedepankan hygiene dari awal sampai dengan penyajian." class="img-circle" alt="makanan" width="304" height="236">
              </div>
              <div class="col-md-4">
 <img src="img/fasilitas/sentuh.jpg" title="Untuk pemilihan lagu menggunakan sistem layar sentuh secara scroll dan sliding dan pilih langsung." class="img-circle" alt="sentuh" width="304" height="236">
              </div>
              <div class="col-md-4">
                  <img src="img/fasilitas/sound.jpg" title="Semua ruangan menggunakan TV layar lebar antara lain TV 32 inch dan 42 inch, dengan jumlah TV yang disesuaikan dengan kapasitas ruangan." class="img-circle" alt="sound" width="304" height="236">
              </div>
 <div class="row">
            <div class="col-lg-12">             
              <div class="col-lg-1">
              <br>
<br></div></div></div>
              <div class="col-md-4">
<img src="img/fasilitas/tv.jpg" title="Semua ruangan menggunakan TV layar lebar antara lain TV 32 inch dan 42 inch, dengan jumlah TV yang disesuaikan dengan kapasitas ruangan." class="img-circle" alt="tv" width="304" height="236">
              </div>
              <div class="col-md-4">

                  <img src="img/fasilitas/volume.jpg" title="Volume suara semua lagu telah di normalisasi, sehingga antara satu lagu dengan lagu lagu yang lainnya volume terdengar stabil." class="img-circle" alt="volume" width="304" height="236">
              </div>
              <div class="col-md-4">
                   
                  <img src="img/fasilitas/wifi.png" title="Free hotspot area." class="img-circle" alt="wifi" width="304" height="236">
              </div>
            </div>
            </div>
        <!-- /.row -->
</div></div></div></div>
        <!-- Footer -->
        <footer>
            
                    <center>Copyright &copy;Bootsrap Team</center>
             
        </footer>


    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
