<script type="text/javascript">
        	function checkform(){		
				if(document.getElementById('tgl_a').value>document.getElementById('tgl_b').value){
					<?php echo "tgl_a date is greater than the tgl_b date. Please Check it First."?>;
					document.getElementById('tgl_a').focus();
					return false;
				}
				
				if(document.getElementById('hiddendate').value>document.getElementById('tgl_a').value){
					alert("Your selected date is in the past. Please select a new date.");
					document.getElementById('tgl_a').focus();
					return false;
				}
				
				if(document.getElementById('xqtyeb').value>document.getElementById('xqty').value){
					alert("Check Your Extra Bed Quantity.  Maximum 1 Extra Bed per Room.");
					document.getElementById('xqtyeb').focus();
					return false;
				}
			}
 </script> 

 <script type="text/javascript">
				Date.prototype.ymd = function (divider) {
					function pad(n) {
						return (n < 10) ? '0' + n : n;
					}
					var divider = (divider == '-') ? divider : '/',
						year = this.getFullYear(),
						month = pad(this.getMonth() + 1),
						day = pad(this.getDate());
					return year + divider + month + divider + day;
				};
				function plusDate() {
					var input = document.getElementById('tgl_a');
					//input.value = new Date().ymd('-');
					var d = new Date(document.getElementById('tgl_a').value.replace(/-/g, '/'));
					d.setTime(d.getTime() + 86400000);
					document.getElementById('tgl_b').value = d.ymd('-');
				};
				function jhari(){
					var dd1=new Date(document.getElementById('tgl_a').value.replace(/-/g, '/'));
					var jd1=dd1.setTime(dd1.getTime());
					var dd2=new Date(document.getElementById('tgl_b').value.replace(/-/g, '/'));
					var jd2=dd2.setTime(dd2.getTime());
					var one_day=1000*60*60*24;
					var jdx=jd2+"-"+jd1;
					var jdx2=eval(jdx);
					var jdx3=jdx2+"/"+one_day;
					var jdx4=eval(jdx3).toFixed(0);
					document.getElementById('night').value=jdx4;
					//alert(jdx4);
				}
			</script>

<script>
var RecaptchaOptions = {
  theme : 'custom',
    custom_theme_widget: 'recaptcha_widget'
};
</script>
<script type="text/javascript">
			$(function(){
				$('*[id= date-time-only]').appendDtpicker({
					"autodateOnStart": false,
					"timeOnly": true,
					"minTime":"09.00",
						"maxTime":"22:00",
						"closeOnSelected": true
					
				});
			});
		</script>
        <script type="text/javascript">
			$(function(){
				$('*[id=date-time-only1]').appendDtpicker({
					"autodateOnStart": false,
					"timeOnly": true,
						"minTime":"10.00",
						"maxTime":"23:00",
						"closeOnSelected": true
					
				});
			});
		</script>

   <div class="col-md-4">
                 <div id="check_avail">
                
                <h3>PESAN SEKARANG : </h3><br>
                <form action="" method="post" id="myform" name="form1">
              <label>Tanggal </label>
                     <a href="javascript:displayDatePicker('tgl_a','','ymd');">
<input name="tgl_a" type="text" class="calendar" id="tgl_a" 
 onFocus="plusDate();" onblur="jhari();" value="<?php echo date("Y-m-d"); ?> "  readonly /></a>
  <fieldset class="col_f_1"> <label>Dari Jam </label>
  <input type="text" id="date-time-only" name="waktuin" readonly="readonly" >
     
        </fieldset>
                        
                    <fieldset class="col_f_2"><label>Sampai Jam </label>
                        <input type="text" id="date-time-only1" name="waktuout"  readonly="readonly">
		
		</fieldset>
        
                   <fieldset><label>Pilih Tipe Ruangan  </label>
                        <select name="tipe">
                                        <?php
					$q=mysql_query("Select * from tb_tipe");
					while($r=mysql_fetch_array($q))
					{
					?>
					<option value="<?php echo $r['id_tipe']; ?>"><?php echo $r['tipe']; ?></option>
                    <?php
					}
					?>
                         </select></fieldset>
                        
                    <center><button type="submit" name="submit" class="btn btn-primary" >&nbsp; &nbsp;Cek  &nbsp; &nbsp; </button></center>
                </form></div></div></div>
                <script>
  $(document).ready(function(){
    $("#myform").validate();
	$(":date").dateinput();
  });
  </script>
  
  
  
  <?php

if(isset($_POST['submit']))
{
	
	$wkt1=($_POST['waktuin']);
	$wkt2=($_POST['waktuout']);
	$ws1=strtotime($_POST['waktuin']);
	$ws2=strtotime($_POST['waktuout']);
	$tipe=$_POST['tipe'];
	$tgl= strtotime($_POST['tgl_a']);
	$d1= strtotime(date("Y-m-d"));
	//$t= strtotime(date("H:i"));
	//$q=mysql_query("Select * from tb_pemesan Where waktu_masuk between '".$wkt1."' and '".$wkt2."' and id_tipe='".$tipe."'"); 
	//$s=mysql_query("Select nomor_ruang,status from tb_ruangan where status='0' and id_tipe='".$tipe."'");
if(($ws1 < $ws2)  && ($tgl > $d1)){	
$qq1=mysql_query("select r.nomor_ruang,r.id_tipe,r.status,p.tgl_pesan,p.waktu_masuk,p.waktu_keluar,p.id_tipe 
from tb_pemesan p LEFT JOIN tb_ruangan r ON r.id_tipe='".$tipe."' Where r.status=0");
while ($r11=mysql_fetch_array($qq1)){	
  $nomor=$r11['nomor_ruang'];

		//$rc=mysql_num_rows($qq1); 
	
		//if($rc=0) { 
	
				$_SESSION['tgl']=$_POST['tgl_a'];
				$_SESSION['wkt1']=$wkt1; 
				$_SESSION['wkt2']=$wkt2; 
				$_SESSION['rm']=$_POST['tipe']; 
				$_SESSION['nomor']= $nomor;
				$_SESSION['ada']="1"; 
				_direct("formpesan.php?id=".session_id());
			//} 
  }}
		else{ 
				unset($_SESSION['tgl']); 
				unset($_SESSION['wkt1']); 
				unset($_SESSION['wkt2']); 
				unset($_SESSION['rm']); 
				unset($_SESSION['ada']); 
				unset($_SESSION['nomor']);
		echo "<script type='text/javascript'>alert('Tolong tanggal atau jam dikondisikan ') ;</script>";
						_direct("pesan.php?id=".session_id()); 

				
	} 
}
    

?>

                