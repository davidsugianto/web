<?php
//CORE
require_once('config.php');
require_once('includes/functions/publicfunc.php');
require_once('includes/functions/dbfunc.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Karaoke</title>

    <!--CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/tanggal.css" type="text/css" rel="stylesheet">
    <link href="css/small-business.css" rel="stylesheet">
    <link rel="stylesheet" href="js/prettyPhoto/css/prettyPhoto.css" type="text/css" media="screen">
	<link type="text/css" href="css/jquery.simple-dtpicker.css" rel="stylesheet" />

<!-- JS -->
    <script src="js/jquery-1.9.1.js"></script> 
     <script src="js/bootstrap.js"></script>        
    <script type="text/javascript" src="js/tanggal.js"></script>
	<script type="text/javascript" src="js/jquery.simple-dtpicker.js"></script>

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <!-- <img src="http://placehold.it/150x50&text=Logo" alt=""> -->
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                 <?php include "menu.php " ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <!-- Heading Row -->
        <div class="row well">
            <div class="col-lg-8">
            <?php
                if(isset($_GET['room']))
{
	$segment="ruangan";
	$sql="Select * from tb_tipe where id_tipe='".$_GET['room']."'";
	$q=mysql_query($sql);
	$r=mysql_fetch_array($q);
	$photo=$base_url."uploads/images/".$r['gambar'];
	echo '
		<h1>'.$r['tipe'].'<br></h1>
		<div class="picture">
		<a href="'.$photo.'" data-rel="prettyPhoto" title=""><span class="magnify"></span><img src="'.$photo.'" alt="picture" class="scale-with-grid" width="300" height="300"></a><em></em>
	</div>
	<strong> Harga : '?> <?php $hrgbm=$r['harga_biasa'] + 10000;//harga khusus hari sabtu minggu pagi
	$hrgsm=$r['harga_sabming'] + 10000;//harga khusus hari sabtu minggu malam
	$hrgnp=$r['harga_biasa'];
	$hrgnm=$r['harga_sabming'];
	if (( date('D')=='Sat' && date('H.i') <= '17.00' ) | (date('D')== 'Sun' && date('H.i') <= '17.00')){
	 echo ("Rp. ").number_format($hrgnm)." / Jam"; 
	 } 
	 	elseif(( date('D')=='Sat' && date('H.i') > '17.00' ) | (date('D')== 'Sun' && date('H.i') > '17.00')){
			 echo ("Rp. ").number_format($hrgsm)." / Jam";
	 }
	 	elseif(date('D') && date('H.i') <= 17.00){
	 		echo ("Rp. ").number_format($hrgnp)." / Jam";
	 }
	 else {
			echo ("Rp. ").number_format($hrgbm)." / Jam"; 
		 }
	?>
	<?php
	echo '
        </p>
        <p>'.$r['deskripsi'].'
        </p>
		</strong>
	';
	}
	?><br>
<br>
<br>

    
            </div>
            <!-- /.col-md-8 -->
                       <?php include "ketersediaan.php" ;?>

            <!-- /.col-md-4 -->
            
        </div>
        <!-- /.row -->

     <div class="main-spacer">
<br>
<br>

</div>  

        
        <!-- /.row -->
</div>

        <!-- Footer -->
        <footer>
           
                    <center>Copyright &copy; Bootsrap Team</center>
             
        </footer>

  
    <!-- /.container -->

    
</body>

</html>
