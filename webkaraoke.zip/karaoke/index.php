<?php
require_once('config.php');
require_once('includes/functions/publicfunc.php');
// digunakan untuk mereset status = 0 jika tgl pemesan melebihi tgl sekarang
$qq=mysql_query("select max(p.tgl_pesan) as t,r.status,p.nomor_ruang,p.waktu_keluar from tb_pemesan p,tb_ruangan r where r.id_tipe=p.id_tipe and r.nomor_ruang=p.nomor_ruang AND r.status=1");
while($r1=mysql_fetch_array($qq)){
	  $tanggal=strtotime($r1['t']);
	$waktukeluar=strtotime($r1['waktu_keluar']);
	 $n= $r1['nomor_ruang'];

if(strtotime(date("Y-m-d")) >= $tanggal && strtotime(date("H:i")) >= $waktukeluar && $r1['status']==1){
$ss=mysql_query("Update tb_ruangan SET status='0' where nomor_ruang='".$n."'") or die(mysql_error());

}
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Karaoke</title>
	<script src="js/jquery-1.9.1.js"></script>
    <script src="js/bootstrap.js"></script>
    <!-- Bootstrap Core CSS -->
    
    <link href="css/bootstrap.css" rel="stylesheet">
   	<link rel="stylesheet" href="js/prettyPhoto/css/prettyPhoto.css" type="text/css" media="screen">
    <link href="css/small-business.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
   <div class="navbar navbar-fixed-top">
<div class="navbar-inverse">
<div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#os-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <!-- <img src="http://placehold.it/150x50&text=Logo" alt=""> -->
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="os-example-navbar-collapse-1">
                <?php include "menu.php " ?>
            </div>
            <!-- /.navbar-collapse -->
        </div></div></div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <!-- Heading Row -->
        <div class="row">
            <div class="col-md-12">
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                      <!-- Indicators -->
                      <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                      </ol>

                      <!-- Wrapper for slides -->
                      <div class="carousel-inner" role="listbox">
                         <div class="item active">
                          <img src="uploads/images/slides/2.jpg" alt="Chania">
                        </div>

                        <div class="item">
                          <img src="uploads/images/slides/3.jpg" alt="Flower">
                        </div>

                        <div class="item">
                          <img src="uploads/images/slides/4.jpg" alt="Flower">
                        </div>
                      </div>
<hr>
                      <!-- Left and right controls -->
                      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                      </a>
                      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                      </a>
                    </div>
            </div>

    

        <!-- Call to Action Well -->
            <div class="col-lg-12">
                <div class=" well text-center">
                    <marquee><h1>Selamat Datang</h1></marquee>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

        <!-- Content Row -->
        <div class="row well">
    
      <div class="col-md-4">
      
 <?php
 // Colom promo ////
$q=mysql_query("SELECT tb_promo.id_promo, tb_tipe.tipe as 'nmclass', tb_tipe.harga_sabming, tb_promo.diskon, tb_promo.tgl_mulai, tb_promo.tgl_akhir,
 tb_promo.deskripsi as 'desc', tb_promo.judul_promo as 'prom', tb_tipe.gambar
FROM tb_promo LEFT JOIN tb_tipe ON tb_promo.id_tipe = tb_tipe.id_tipe order by tgl_akhir ASC Limit 0,1");

$r=mysql_fetch_array($q);
$photo=$base_url."uploads/images/".$r['gambar'];
	
	
echo '
	<h2>Promo <strong>'.$r['nmclass'].'</strong></h2>
    <h3>Hingga <strong>'.tgl_indo($r['tgl_akhir']).'</strong></h3>
    <div class="picture">
    
    <a href="'.$photo.'" data-rel="prettyPhoto" title=""><span class="magnify"></span><img src="'.$photo.'" alt="picture" class="scale-with-grid"></a><em></em></a></div>
	';
     
		echo "<p>".limit_200($r['desc']).".."."</p>";
	

?>
	<a href="infopromo.php<?php echo "?promo=".$r['id_promo']; ?>" class="btn btn-info">Lebih Lanjut</a>

            </div>
           <?php
///// Colom Ruangan ////
$q=mysql_query("Select * from tb_tipe LIMIT 0,3");
while($r=mysql_fetch_array($q))
{
	$photo=$base_url."uploads/images/".$r['gambar'];
	$id=$r['id_tipe'];
?>
<div class="col-md-2">
<br>

	<div class="picture">
		<a href="<?php echo $photo; ?>" data-rel="prettyPhoto" title=""><span class="magnify "></span><img src="<?php echo $photo; ?>" alt="picture" class="scale-with-grid"></a><em></em>
	</div>
	<h4><?php echo $r['tipe']; ?> <strong>
<?php 
	$hrgbm=$r['harga_biasa'] + 10000;//harga khusus hari sabtu minggu pagi
	$hrgsm=$r['harga_sabming'] + 10000;//harga khusus hari sabtu minggu malam
	$hrgnp=$r['harga_biasa'];
	$hrgnm=$r['harga_sabming'];
	if (( date('D')=='Sat' && date('H.i') <= '17.00' ) | (date('D')== 'Sun' && date('H.i') <= '17.00')){
	 echo ("Rp. ").number_format($hrgnm)." / Jam"; 
	 } 
	 	elseif(( date('D')=='Sat' && date('H.i') > '17.00' ) | (date('D')== 'Sun' && date('H.i') > '17.00')){
			 echo ("Rp. ").number_format($hrgsm)." / Jam";
	 }
	 	elseif(date('D') && date('H.i') <= 17.00){
	 		echo ("Rp. ").number_format($hrgnp)." / Jam";
	 }
	 else {
			echo ("Rp. ").number_format($hrgbm)." / Jam"; 
		 }
	?></strong></h4>
		<br class="clear add-bottom"/>
	<a href="detail_ruangan.php<?php echo "?room=". _encodeParam($id); ?>" class="btn btn-success">Lebih Lanjut</a>
    
</div>
<?php
}
////////////////////////////
?>
    
        </div>
        </div>
        <!-- /.row -->
        <div class="main-spacer">
</div>
        <!-- Footer -->
        <footer>
                    <center>Copyright &copy; Bootsrap Team</center>
        </footer>

 
    <!-- /.container -->

    <!-- jQuery -->
    <script type="text/javascript"  src="js/plug_ins.js"></script>  
      <script src="js/functions.js"></script>

    <!-- Bootstrap Core JavaScript -->

</body>

</html>
