<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Karaoke</title>

   <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/tanggal.css" type="text/css" rel="stylesheet">
    <link href="css/small-business.css" rel="stylesheet">
    <link rel="stylesheet" href="js/prettyPhoto/css/prettyPhoto.css" type="text/css" media="screen">
<!-- JS -->
    <script src="js/jquery-1.9.1.js"></script> 
     <script src="js/bootstrap.js"></script>        
    <script type="text/javascript" src="js/tanggal.js"></script>

    

</head>

<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <!-- <img src="http://placehold.it/150x50&text=Logo" alt=""> -->
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <?php include "menu.php " ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <!-- Heading Row -->
        <div class="row well">
            <div class="col-md-6">
                <h2>Alamat :</h2>
                <h3> &nbsp;&nbsp; Jl.Example No.109 Jember Jawa Timur,68174</h3><br>
				<h2>No.Telp : </h2>
                <h3>&nbsp;&nbsp;082257844803 </h3><br>
                <h2>E-mail :</h2>
                <h3>&nbsp;&nbsp;Asksong@gmail.com</h3>
 
                <div class="col-md-12">
            <img class="img-responsive" src="img/1.jpg">
            
          </div>
            
            </div>
            
            <div class="col-md-6">
            
                   <center><strong>Hubungi kami secara online dengan mengisi form di bawah ini :</strong></center><br><br>
                               <?php
if(isset($_POST['submit'])){
	
if($_POST['nama'] != ''){
	include "config.php";
    $nama=mysql_real_escape_string($_POST['nama']);
    $email=mysql_real_escape_string($_POST['email']);
    $subjek=($_POST['sub']);
    $pesan=strip_tags($_POST['pesan']);
	$tgl=date('Y'.'-'.'m'.'-'.'d');
   $sql = mysql_query("INSERT INTO tb_hubungi values (' ','$nama','$email','$subjek','$pesan','$tgl')");
echo "<script>window.location=('aksi_hubungi.php')</script>";
}else{
        echo "<script type='text/javascript'>alert(' yang bertanda (*) harus diisi') ;</script>";
		}
	}

?>

               </div>
               
                   <div class="col-md-4">
                   <!--proses input ke tb_hubungi-->
                  <form class="form-horizontal" method="post" >
                                 <label> Nama <font color="#FF0000">*</font></label>
                                        <input type="text" id="nama" name="nama">
                                  <label for="email">E-mail<font color="#FF0000">*</font></label>
                                  <input type="email" id="email" name="email">
                                 Subjek :
                                    <input type="radio" name="sub" value="saran" checked>  Keluhan
                                     
                                   	    &nbsp;<input type="radio" name="sub" value="request lagu"> Request Lagu<label> <br> </label>
                                  <label for="comment">Pesan :</label>
                                  <textarea class="form-control" rows="5" id="comment" name="pesan"></textarea>
                              
                              <font color="#FF0000">*</font> Harus Diisi <br><br>
                                
                                  <input type="submit" class="btn btn-primary btn-lg" value="Kirim" name="submit">
                    </form>
                         
                    </div>
                      
                 </div>
            <!-- /.col-md-4 -->
         
        
              </div>
        <!-- /.row -->
<div class="main-spacer"><br>

        </div>
        <!-- Footer -->
        <footer>
            
                    <center>Copyright &copy; Bootsrap Team</center>
                
        </footer>

   
    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    
    

</body>

</html>
