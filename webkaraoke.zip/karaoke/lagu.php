<?php
//CORE
require_once('config.php');
require_once('includes/functions/publicfunc.php');
require_once('includes/functions/dbfunc.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Karaoke</title>
	<script src="js/jquery-1.9.1.js"></script>
    <script src="js/bootstrap.js"></script>
    <!-- Bootstrap Core CSS -->
    
    <link href="css/bootstrap.css" rel="stylesheet">
   	<link rel="stylesheet" href="js/prettyPhoto/css/prettyPhoto.css" type="text/css" media="screen">
    <link href="css/small-business.css" rel="stylesheet">


</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <!-- <img src="http://placehold.it/150x50&text=Logo" alt=""> -->
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <?php include "menu.php " ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <!-- Heading Row -->
        <div class="row well">
            <div class="col-lg-12"><center>
                     <form class="form-horizontal"  method="post">
                            <div class="form-group">
                            <label class="col-sm-2 control-label">Cari Artis</label>
                            <div class="col-sm-2">
                            <input type="text" name="artis">                        
                     </div>
                     <!-- <div class="col-sm-2">
                      <input type="submit" class="btn btn-primary btn-lg" name="cari" value="Cari">
</div> -->
                     </div>
                    </form></center>
                </div>
                
                <div class="col-lg-12">
            
              
              <div class="tab-content">
                <div id="nama" class="tab-pane fade in active">
                  <div class="col-lg-12">
                   <h2 class="text-center">Artis</h2>
                </div>
                
                <?php
				$a = $_POST['artis'];
if(isset($a))
{

	$q=mysql_query("SELECT * FROM tb_artis  WHERE 
	(nama LIKE '%$a%') ORDER BY nama ");
}
else

{
		$q=mysql_query("SELECT * FROM tb_artis order by nama");
}


while($r=mysql_fetch_array($q))
{
	?>
<div class="col-md-1">
<br>

	<div class="picture">
    <?php
	
$photo=$base_url."uploads/images/album/".$r['gambar'];
echo'<span class="magnify"></span>
<img alt="picture" src="'.$photo.'"  class="scale-with-grid"></a><em></em></div>

                  <a href= "artissearch.php?id='.$r['id_artis'].'"><center>'.$r['nama'].'</center> </a>';
?>
</div>
<?php
}
 ?>
                </div>
                
                               
               
                    
                        
                    </div>
                </div>
        </div>
        <!-- /.row -->
<div class="main-spacer">
<br>
<br>
<br>

</div>


        </div>

        <!-- Footer -->
        <footer>
            
                    <center>Copyright &copy; Bootstrap Team</center>
              
        </footer>

    </div>
    <!-- /.container -->
    


   <script type="text/javascript"  src="js/plug_ins.js"></script>  
      <script src="js/functions.js"></script>

</body>

</html>
