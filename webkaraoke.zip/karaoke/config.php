<?php
session_start();
$basefolder="karaoke";
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="karaoke1";
$base_url="http://localhost/".$basefolder."/";
$con=mysql_connect($dbhost,$dbuser,$dbpass) or die(mysql_error());
$rs=mysql_select_db($dbname);
$pathfolder = "C:\xampp\htdocs\karaoke"; 
//$pathfolder = "C:\xampp\htdocs\hottttttt"; 
?>