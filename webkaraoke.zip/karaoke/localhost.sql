-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 13. Desember 2016 jam 21:01
-- Versi Server: 5.1.33
-- Versi PHP: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `karaoke1`
--
CREATE DATABASE `karaoke1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `karaoke1`;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_artis`
--

CREATE TABLE IF NOT EXISTS `tb_artis` (
  `id_artis` int(10) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  `gambar` varchar(30) NOT NULL,
  PRIMARY KEY (`id_artis`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `tb_artis`
--

INSERT INTO `tb_artis` (`id_artis`, `nama`, `gambar`) VALUES
(1, 'NOAH', 'noah.jpg'),
(2, 'IWAN FALS', 'iwan.jpg'),
(3, 'UNGU', 'ungu.jpg'),
(4, 'GREENDAY', 'greenday.jpg'),
(7, 'RERE', 'No_artis.jpg'),
(6, 'Tipe X', 'No_artis.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_daftarlagu`
--

CREATE TABLE IF NOT EXISTS `tb_daftarlagu` (
  `id_lagu` int(10) NOT NULL AUTO_INCREMENT,
  `id_artis` int(10) NOT NULL,
  `judul_lagu` varchar(50) NOT NULL,
  `jenis_lagu` varchar(50) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `bahasa` varchar(10) NOT NULL,
  PRIMARY KEY (`id_lagu`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data untuk tabel `tb_daftarlagu`
--

INSERT INTO `tb_daftarlagu` (`id_lagu`, `id_artis`, `judul_lagu`, `jenis_lagu`, `tahun`, `bahasa`) VALUES
(1, 1, 'Separuh Aku', 'POP', '2015', 'indo'),
(2, 1, 'Sendiri lagi', 'POP', '2015', 'indo'),
(3, 4, 'Trouble Maker', 'ROCK', '2013', 'Inggris'),
(4, 4, 'Warning', 'ROCK', '2014', 'Inggris'),
(5, 2, 'Bento', 'POP', '2013', 'indo'),
(6, 2, 'Pesawat Tempur', 'POP', '2011', 'indo'),
(7, 3, 'Hampa hatiku', 'POP', '2009', 'indo'),
(8, 3, 'Surgamu', 'POP', '2008', 'indo'),
(9, 3, 'Demi Nafas', 'POP', '2013', 'indo'),
(11, 3, 'CINTA GILA', 'POP', '2011', 'indo'),
(16, 1, 'Semua Tentang Kita', 'POP', '2001', 'indo'),
(17, 1, 'Ada Apa Denganmu', 'POP', '1996', 'indo');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_email`
--

CREATE TABLE IF NOT EXISTS `tb_email` (
  `pemilik` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_email`
--

INSERT INTO `tb_email` (`pemilik`, `email`) VALUES
('asksong', 'Asksong@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_hubungi`
--

CREATE TABLE IF NOT EXISTS `tb_hubungi` (
  `id_hubungi` int(10) NOT NULL AUTO_INCREMENT,
  `nama_pengirim` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subjek` varchar(20) NOT NULL,
  `pesan` longtext NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id_hubungi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data untuk tabel `tb_hubungi`
--

INSERT INTO `tb_hubungi` (`id_hubungi`, `nama_pengirim`, `email`, `subjek`, `pesan`, `tanggal`) VALUES
(1, 'yusfi', 'yusfiadil@gmail.com', 'request', 'Iwan Fals Bento', '2016-11-23'),
(11, 'David', 'Davids@gmail.com', 'saran', 'Pelayananya Kurang', '2016-12-01');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_login`
--

CREATE TABLE IF NOT EXISTS `tb_login` (
  `username` varchar(10) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_login`
--

INSERT INTO `tb_login` (`username`, `password`) VALUES
('yusfi1997', 'eeaeda85a4314e86ac5deb8102741e4d'),
('kelompok4', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pemesan`
--

CREATE TABLE IF NOT EXISTS `tb_pemesan` (
  `id_pemesan` int(10) NOT NULL AUTO_INCREMENT,
  `tgl_pesan` date NOT NULL,
  `waktu_masuk` varchar(10) NOT NULL,
  `waktu_keluar` varchar(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `jkel` varchar(15) NOT NULL,
  `telp` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `alamat` text NOT NULL,
  `id_tipe` int(10) NOT NULL,
  `nomor_ruang` varchar(15) NOT NULL,
  PRIMARY KEY (`id_pemesan`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `tb_pemesan`
--

INSERT INTO `tb_pemesan` (`id_pemesan`, `tgl_pesan`, `waktu_masuk`, `waktu_keluar`, `nama`, `jkel`, `telp`, `email`, `alamat`, `id_tipe`, `nomor_ruang`) VALUES
(1, '2016-12-06', '10:00', '11:00', 'Yusfi Adil A', 'lakilaki', '082257844803', 'yusfiadil@gmail.com', 'Jember', 11, 'Besar3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_promo`
--

CREATE TABLE IF NOT EXISTS `tb_promo` (
  `id_promo` int(10) NOT NULL AUTO_INCREMENT,
  `id_tipe` varchar(5) NOT NULL,
  `judul_promo` text NOT NULL,
  `tgl_mulai` date NOT NULL,
  `tgl_akhir` date NOT NULL,
  `diskon` int(3) NOT NULL,
  `deskripsi` longtext NOT NULL,
  PRIMARY KEY (`id_promo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `tb_promo`
--

INSERT INTO `tb_promo` (`id_promo`, `id_tipe`, `judul_promo`, `tgl_mulai`, `tgl_akhir`, `diskon`, `deskripsi`) VALUES
(1, '9', 'Promo Hemat', '2016-12-03', '2016-12-21', 10, '<p><span style="font-family:comic sans ms,cursive">ayooo buruan Ke asksong karaoke !!! </span></p>\r\n\r\n<p><span style="font-family:comic sans ms,cursive">Untuk memperingati hari......... Asksong karaoke Memberi </span></p>\r\n\r\n<p><span style="font-family:comic sans ms,cursive">Diskon diatas jam 17.00 WIB</span> dengan harga tertera diatas</p>\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_ruangan`
--

CREATE TABLE IF NOT EXISTS `tb_ruangan` (
  `id_ruang` int(10) NOT NULL AUTO_INCREMENT,
  `nomor_ruang` varchar(20) NOT NULL,
  `id_tipe` int(10) NOT NULL,
  `status` int(1) NOT NULL,
  `nama_ruang` varchar(20) NOT NULL,
  PRIMARY KEY (`id_ruang`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data untuk tabel `tb_ruangan`
--

INSERT INTO `tb_ruangan` (`id_ruang`, `nomor_ruang`, `id_tipe`, `status`, `nama_ruang`) VALUES
(1, 'Kecil1', 9, 0, 'Kecil'),
(2, 'Kecil2', 9, 0, 'Kecil'),
(3, 'Kecil3', 9, 0, 'Kecil'),
(4, 'Kecil4', 9, 0, 'Kecil'),
(5, 'Kecil5', 9, 0, 'Kecil'),
(6, 'Sedang1', 10, 0, 'Sedang'),
(7, 'Sedang2', 10, 0, 'Sedang'),
(8, 'Sedang3', 10, 0, 'Sedang'),
(9, 'Sedang4', 10, 0, 'Sedang'),
(10, 'Besar1', 11, 0, 'Besar'),
(11, 'Besar2', 11, 0, 'Besar'),
(12, 'Besar3', 11, 0, 'Besar');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_tipe`
--

CREATE TABLE IF NOT EXISTS `tb_tipe` (
  `id_tipe` int(10) NOT NULL AUTO_INCREMENT,
  `tipe` varchar(10) NOT NULL,
  `harga_biasa` int(30) NOT NULL,
  `harga_sabming` int(30) NOT NULL,
  `deskripsi` longtext NOT NULL,
  `max` char(2) NOT NULL,
  `gambar` varchar(50) NOT NULL,
  PRIMARY KEY (`id_tipe`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data untuk tabel `tb_tipe`
--

INSERT INTO `tb_tipe` (`id_tipe`, `tipe`, `harga_biasa`, `harga_sabming`, `deskripsi`, `max`, `gambar`) VALUES
(9, 'Small', 20000, 30000, '<p>Ini adalah ruangan karaoke kecil</p>\r\n', '4', 'g_21112016.jpg'),
(10, 'Medium', 30000, 50000, 'ini medium\r\n', '6', 'kara_19112016.jpg'),
(11, 'Large', 50000, 60000, 'Ini Ruangan Large\r\n', '8', 'karaokeqstudiolasvegasnew2_20112016.jpg');
