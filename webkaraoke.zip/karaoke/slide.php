
			<li>
			<a href="#"><img src="<?php echo $base_url."/uploads/images/slides/1.jpg"; ?>" alt=""></a>
			<p class="flex-caption">
				 ASKSONG KARAOKE.
			</p>
			</li>
			<li>
			<a href="#"><img src="<?php echo $base_url."/uploads/images/slides/2.jpg"; ?>" alt=""></a>
			<p class="flex-caption">
				 ASKSONG KARAOKE.
			</p>
			</li>
			<li>
			<a href="#"><img src="<?php echo $base_url."/uploads/images/slides/3.jpg"; ?>" alt=""></a>
			<p class="flex-caption">
				 ASKSONG KARAOKE.
			</p>
			</li>
			<li>
			<a href="#"><img src="<?php echo $base_url."/uploads/images/slides/4.jpg"; ?>" alt=""></a>
			<p class="flex-caption">
				 ASKSONG KARAOKE.
			</p>
			</li>
		