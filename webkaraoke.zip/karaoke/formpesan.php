<?php

require_once('config.php');
require_once('includes/functions/publicfunc.php'); 

if(!isset($_SESSION['ada']))
{
_direct("pesan.php?id=".session_id()); 
}else{
?> 
<!DOCTYPE html>
<html lang="en">

<head>


    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Karaoke</title>

    <!--CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/tanggal.css" type="text/css" rel="stylesheet">
    <link href="css/small-business.css" rel="stylesheet">
    <link rel="stylesheet" href="js/prettyPhoto/css/prettyPhoto.css" type="text/css" media="screen">
	<link type="text/css" href="css/jquery.simple-dtpicker.css" rel="stylesheet" />

<!-- JS -->
    <script src="js/jquery-1.9.1.js"></script> 
     <script src="js/bootstrap.js"></script>        
    <script type="text/javascript" src="js/tanggal.js"></script>
	<script type="text/javascript" src="js/jquery.simple-dtpicker.js"></script>

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">
                    <!-- <img src="http://placehold.it/150x50&text=Logo" alt=""> -->
                </a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <?php include "menu.php " ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <!-- Page Content -->
    <div class="container">

        <!-- Heading Row -->
        <div class="row well">
            <div class="col-md-8">
          
   
	
           
             <form method="post" class="form-horizontal">
             <h1><?php 
$s1=$_SESSION['rm']; 
$p1=mysql_query("Select * from tb_tipe where id_tipe='".$s1."'");
$pr1=mysql_fetch_array($p1);
echo "Anda Akan Memesan Ruangan Dengan Tipe ".$pr1['tipe']."<br></h1>"; 
echo "<h2> Dengan Nama Ruangan ".$_SESSION['nomor'];
?></h2>
<h3>Dari Jam <b><?php echo $_SESSION['wkt1']; ?></b> Sampai Jam <?php echo $_SESSION['wkt2']; ?></h3>
<h3>Pada Tanggal <b><?php echo tgl_indo($_SESSION['tgl']); ?></b></h3>

                         <fieldset><label> Sebutan </label>
                        <select name="jkel">
                         <option value="laki-laki">Tuan</option>
                         <option value="perempuan">Nyonya</option>
                         </select></fieldset>
                         <fieldset><label>Nama <font color="#FF0000">*</font> </label><input type="text" name="nama" maxlength="30" >
                        	</fieldset>
                         <fieldset><label>No telp <font color="#FF0000">*</font> </label><input type="text" name="tlp" maxlength="15" >
                        	</fieldset>
                         <fieldset><label>Email </label><input type="email" name="email" id="email" maxlength="30" >
                        	</fieldset>
                         <fieldset><label>Alamat <font color="#FF0000">*</font></label><textarea  name="alamat" ></textarea>
                        
                        	</fieldset>
                                                       <font color="#FF0000">*</font> Harus Diisi <br><br>

                    <input type="submit" name="submit" value="Pesan" class="btn btn-primary"> 
                    <input type="submit" name="batal" value="Batal" class="btn btn-danger">
                </form>
            
            </div>


            <!-- /.col-md-8 -->
<?php
if(isset($_POST['submit']))
{
	if($_POST['nama'] != '' && ($_POST['tlp']) !='' && ($_POST['alamat'] != '')){

	
	$q=mysql_query("INSERT INTO tb_pemesan VALUES('','".$_SESSION['tgl']."', '".$_SESSION['wkt1']."', '".$_SESSION['wkt2']."', '".$_POST['nama']."', '".$_POST['jkel']."', '".$_POST['tlp']."', '".$_POST['email']."', '".$_POST['alamat']."', '".$_SESSION['rm']."', '".$_SESSION['nomor']."')");
	$p=mysql_query("UPDATE tb_ruangan SET status='1' where nomor_ruang='".$_SESSION['nomor']."'");
	if($q)
	{
				unset($_SESSION['tgl']); 
				unset($_SESSION['wkt1']); 
				unset($_SESSION['wkt2']); 
				unset($_SESSION['rm']); 
				unset($_SESSION['nomor']);
				unset($_SESSION['ada']); 
echo "<script type='text/javascript'>alert('Terimakasih') ;</script>";
			_direct("pesan.php?id=".session_id());
	}
	
}else{
        echo "<script type='text/javascript'>alert(' yang bertanda (*) harus diisi') ;</script>";

}
}

if(isset($_POST['batal']))
{
				unset($_SESSION['tgl']); 
				unset($_SESSION['wkt1']); 
				unset($_SESSION['wkt2']); 
				unset($_SESSION['rm']); 
				unset($_SESSION['nomor']);
				unset($_SESSION['ada']); 
	_direct("pesan.php?id=".session_id());}
?>       
            </div>
            <!-- /.col-md-4 -->
        </div>
        <!-- /.row -->


  </div>
  


        <!-- /.row -->

        <div class="main-spacer">
<br>
<br>
</div>
 
        <!-- Footer -->
        <footer>
           
                    <center>Copyright &copy; Bootsrap Team</center>
            
        </footer>


    <!-- /.container -->

    <!-- jQuery -->
    

</body>

</html>
<?php
}
?>
