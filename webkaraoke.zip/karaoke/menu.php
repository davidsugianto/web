<ul class=" nav navbar-nav">
                    <li>
                        <a  href="index.php">Beranda</a>
                    </li>
                    <li>
                        <a href="pesan.php<?php echo "?id=".session_id(); ?>">Pemesanan</a>
                    </li>
                    <li>
                        <a href="fasilitas.php">Fasilitas</a>
                    </li>
                    <li>
                        <a href="lagu.php">Daftar Lagu</a>
                    </li>
                    <li>
                        <a href="hubungi.php">Hubungi Kami</a>
                    </li>
                </ul>